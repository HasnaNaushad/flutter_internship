import 'package:flutter/material.dart';
import 'package:flutter_internship/colors.dart';




void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HARMONIX',
      theme: ThemeData(
        primaryColor: mprimary,

      ),
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true, // Center aligns the title
        title: Text('HARMONIX',

          style: TextStyle(fontSize: 34,
              fontStyle: FontStyle.normal,
              color: const Color(0xFFF5F5F5),
              backgroundColor: const Color(0xFFDFC0A3),
              fontWeight: FontWeight.bold),),

      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('LOGIN',
              style: TextStyle(fontSize: 30,
                  color: const Color(0xFFDFC0A3),
                  fontWeight: FontWeight.bold
              ),


            ),
            SizedBox(height: 16),
            Container(
              width: 250, // Set the desired width here
              child: TextFormField(
                decoration: InputDecoration(
                  labelText: 'Email',
                ),
              ),
            ),
            SizedBox(height: 8),
            Container(
              width: 250, // Set the desired width here
              child: TextFormField(
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Password',
                ),
              ),
            ),
            SizedBox(height: 18),
            ElevatedButton(
              onPressed: () {
                // TODO: Handle login logic
              },
              child: Text('Login', style: TextStyle(color: Colors.white)),
            ),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RegisterPage()),
                );
              },
              child: Text('Create an Account'),
            ),
          ],
        ),
      ),
    );
  }
}

class RegisterPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
          title: Text(
            'HARMONIX',
            style: TextStyle(
              fontSize: 34,
              fontStyle: FontStyle.normal,
              color: const Color(0xFFF5F5F5),
              backgroundColor: const Color(0xFFDFC0A3),
              fontWeight: FontWeight.bold,
            ),
          ),

      ),




      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'REGISTER',
              style: TextStyle(fontSize: 28, color: const Color(0xFFDFC0A3)),
            ),
            SizedBox(height: 16),
            Container(
              width: 250, // Set the desired width here
              child: TextFormField(
                decoration: InputDecoration(
                  labelText: 'Email',
                ),
              ),
            ),
            SizedBox(height: 8),
            Container(
              width: 250, // Set the desired width here
              child: TextFormField(
                obscureText: true,
                decoration: InputDecoration(
                  labelText: 'Password',
                ),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                // TODO: Handle registration logic
              },
              child: Text(
                'Register',
                style: TextStyle(color: Colors.white),
              ),
            ),



            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Already have an account?'),
            ),
          ],
        ),
      ),
    );
  }
}