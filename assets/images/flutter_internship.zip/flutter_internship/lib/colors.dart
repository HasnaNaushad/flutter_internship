import 'package:flutter/material.dart';

const MaterialColor mprimary = MaterialColor(_mprimaryPrimaryValue, <int, Color>{
  50: Color(0xFFFBF7F4),
  100: Color(0xFFF5ECE3),
  200: Color(0xFFEFE0D1),
  300: Color(0xFFE9D3BF),
  400: Color(0xFFE4C9B1),
  500: Color(_mprimaryPrimaryValue),
  600: Color(0xFFDBBA9B),
  700: Color(0xFFD7B291),
  800: Color(0xFFD2AA88),
  900: Color(0xFFCA9C77),
});
 const int _mprimaryPrimaryValue = 0xFFDFC0A3;

 const MaterialColor mprimaryAccent = MaterialColor(_mprimaryAccentValue, <int, Color>{
  100: Color(0xFFFFFFFF),
  200: Color(_mprimaryAccentValue),
  400: Color(0xFFFFF0E5),
  700: Color(0xFFFFE2CB),
});
 const int _mprimaryAccentValue = 0xFFFFFFFF;