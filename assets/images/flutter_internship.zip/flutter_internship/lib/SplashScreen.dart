import 'package:flutter_internship/SplashScreen.dart';

import 'package:flutter/material.dart';


class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {


  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image(image: AssetImage('assets/images/logo.png')),
              SizedBox(height: 10,),
              Text("HARMONIX",

                style: TextStyle(fontSize: 28,
                    fontStyle: FontStyle.normal,
                    color: const Color(0xFFDFC0A3),
                    fontWeight: FontWeight.bold),




              )
            ],
          ),
        ),
      ),
    );
  }

}
