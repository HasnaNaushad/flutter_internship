package com.example.flutter_internship;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
