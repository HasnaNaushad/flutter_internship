import 'package:flutter/material.dart';
import 'package:flutter_internship/ArtistPage.dart';
import 'package:flutter_internship/InfoPage.dart';
import 'package:flutter_internship/SettingsPage.dart';
import 'package:flutter_internship/colors.dart';
import 'package:flutter_internship/PlaylistPage.dart';
import 'package:flutter_internship/homescreen.dart';
import 'package:flutter_internship/AccountPage.dart';

void main() {
  runApp(MusicPlayerApp());
}

class MusicPlayerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Music Player',
      theme: ThemeData(
        primarySwatch: mprimary, // Replace `mprimary` with a color from your `colors.dart` file or use `Colors.blue` as an example
      ),
      home: Albumpage(),
    );
  }
}

class Albumpage extends StatelessWidget {
  final List<String> songs = List.generate(20, (index) => 'Song ${index + 1}');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('HARMONIX', style: TextStyle(color: const Color(0x0FFBD9458))),
        actions: [
          IconButton(
            icon: Icon(Icons.account_circle, color: const Color(0x0FFBD9458),),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AccountPage()),
              );
            },
          ),
          PopupMenuButton<String>(
            icon: Icon(Icons.more_vert, color: const Color(0xFFBD9458),),
            itemBuilder: (BuildContext context) => [
              PopupMenuItem<String>(
                value: 'option1',
                child: Text('Settings'),
              ),
              PopupMenuItem<String>(
                value: 'option2',
                child: Text('Info'),
              ),

            ],
            onSelected: (String value) {
              // Handle menu option selection logic
              if (value == 'option1') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SettingsPage()),
                );
                // Handle option 1 logic
              } else if (value == 'option2') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => InfoPage()),
                );
                // Handle option 2 logic
              }
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(16.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HomeScreen()),
                  );
                  // Button 1 onPressed logic
                },
                style: ButtonStyle(backgroundColor: MaterialStateProperty.all(Colors.grey)),
                child: Text('ALL', style: TextStyle(color: Colors.white)),
              ),
              ElevatedButton(
                onPressed: () {
                  // Button 2 onPressed logic
                },
                child: Text('ALBUM', style: TextStyle(color: Colors.white)),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => PlaylistPage(folders: folders)),
                  );
                  // Button 3 onPressed logic
                },
                style: ButtonStyle(backgroundColor: MaterialStateProperty.all(Colors.grey)),
                child: Text('PLAYLIST', style: TextStyle(color: Colors.white)),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ArtistPage()),
                  );
                  // Button 4 onPressed logic
                },
                style: ButtonStyle(backgroundColor: MaterialStateProperty.all(Colors.grey)),
                child: Text('ARTIST', style: TextStyle(color: Colors.white)),
              ),
            ],
          ),
          Expanded(
            child: AlbumScreen(),
          ),
        ],
      ),
    );
  }
}

class AlbumScreen extends StatelessWidget {
  final List<String> albums = [
    'Album 1',
    'Album 2',
    'Album 3',
    'Album 4',
    'Album 5',
    'Album 6',
    'Album 7',
    'Album 8',
  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: EdgeInsets.all(16.0),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        crossAxisSpacing: 16.0,
        mainAxisSpacing: 16.0,
        childAspectRatio: 0.6,
      ),
      itemCount: albums.length,
      itemBuilder: (context, index) {
        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AlbumDetailsScreen(album: albums[index]),
              ),
            );
          },
          child: Container(
            color: const Color(0x0FFBD9458),
            child: Center(
              child: Text(
                albums[index],
                style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        );
      },
    );
  }
}

class AlbumDetailsScreen extends StatelessWidget {
  final String album;

  AlbumDetailsScreen({required this.album});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Album Details'),
      ),
      body: Center(
        child: Text(
          'Album: $album',
          style: TextStyle(fontSize: 24.0),
        ),
      ),
    );
  }
}



