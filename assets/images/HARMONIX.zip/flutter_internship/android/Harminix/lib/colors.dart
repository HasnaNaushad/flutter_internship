import 'package:flutter/material.dart';

 const MaterialColor mprimary = MaterialColor(_mprimaryPrimaryValue, <int, Color>{
  50: Color(0xFFE3E1E1),
  100: Color(0xFFB8B4B4),
  200: Color(0xFF898282),
  300: Color(0xFF5A4F4F),
  400: Color(0xFF362A2A),
  500: Color(_mprimaryPrimaryValue),
  600: Color(0xFF110303),
  700: Color(0xFF0E0303),
  800: Color(0xFF0B0202),
  900: Color(0xFF060101),
});
 const int _mprimaryPrimaryValue = 0xFF130404;

 const MaterialColor mprimaryAccent = MaterialColor(_mprimaryAccentValue, <int, Color>{
  100: Color(0xFFFF4D4D),
  200: Color(_mprimaryAccentValue),
  400: Color(0xFFE60000),
  700: Color(0xFFCD0000),
});
 const int _mprimaryAccentValue = 0xFFFF1A1A;