import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: AccountPage(),
  ));
}

class AccountPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('USER DETAILS', style: TextStyle(color: const Color(0xFFF95793F))),
      ),
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              Container(
                width: 160,
                height: 160,
                decoration: BoxDecoration(
                  color: const Color(0x0FFBD9458),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.person,
                  size: 80,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 16),
              TextButton(
                onPressed: () {},
                child: const Text("EDIT PROFILE"),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ListView.separated(
                    shrinkWrap: true,
                    itemBuilder: (ctx, index) {
                      IconData icon;
                      String text;
                      if (index == 0) {
                        icon = Icons.person;
                        text = "Your Name";
                      } else if (index == 1) {
                        icon = Icons.info;
                        text = "Address";
                      } else {
                        icon = Icons.phone;
                        text = "Contact";
                      }
                      return ListTile(
                        leading: Icon(icon),
                        title: Text(text),
                      );
                    },
                    separatorBuilder: (ctx, index) {
                      return const Divider(
                        thickness: 1.0,
                        color: Colors.grey,
                      );
                    },
                    itemCount: 3,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
