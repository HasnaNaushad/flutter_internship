import 'package:flutter_internship/SplashScreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_internship/login.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.white,
        child: SafeArea(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image(image: AssetImage('assets/images/harmonic.jpg')),
                SizedBox(height: 10),
                Text(
                  "HARMONIX",
                  style: TextStyle(
                    fontSize: 28,
                    fontStyle: FontStyle.normal,
                    color: const Color(0xFFF95793F),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
