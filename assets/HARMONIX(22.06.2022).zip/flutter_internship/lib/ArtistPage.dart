import 'package:flutter/material.dart';
import 'package:flutter_internship/AlbumPage.dart';
import 'package:flutter_internship/colors.dart';
import 'package:flutter_internship/PlaylistPage.dart';
import 'package:flutter_internship/homescreen.dart';
import 'package:flutter_internship/AccountPage.dart';
import 'package:flutter_internship/SettingsPage.dart'; // Import the SettingsPage
import 'package:flutter_internship/InfoPage.dart'; // Import the InfoPage

void main() {
  runApp(MusicPlayerApp());
}

class MusicPlayerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Music Player',
      theme: ThemeData(
        primarySwatch: mprimary,
      ),
      home: ArtistPage(),
    );
  }
}

class ArtistPage extends StatefulWidget {
  @override
  _ArtistPageState createState() => _ArtistPageState();
}

class _ArtistPageState extends State<ArtistPage> {
  final List<String> artists = [
    'Artist 1',
    'Artist 2',
    'Artist 3',
    'Artist 4',
    'Artist 5',
    'Artist 6',
    'Artist 7',
    'Artist 8',
    'Artist 9',
    'Artist 10',
  ];

  List<String> filteredArtists = [];

  @override
  void initState() {
    super.initState();
    filteredArtists.addAll(artists);
  }

  void filterArtists(String query) {
    filteredArtists.clear();
    if (query.isNotEmpty) {
      final lowercaseQuery = query.toLowerCase();
      artists.forEach((artist) {
        if (artist.toLowerCase().contains(lowercaseQuery)) {
          filteredArtists.add(artist);
        }
      });
    } else {
      filteredArtists.addAll(artists);
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('HARMONIX', style: TextStyle(color: const Color(0xFFBD9458))),
        actions: [
          IconButton(
            icon: Icon(Icons.account_circle, color: const Color(0x0FFBD9458),),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AccountPage()),
              );
            },
          ),
          PopupMenuButton<String>(
            icon: Icon(Icons.more_vert, color: const Color(0xFFBD9458)),
            itemBuilder: (BuildContext context) => [
              PopupMenuItem<String>(
                value: 'option1',
                child: Text('Settings'),
              ),
              PopupMenuItem<String>(
                value: 'option2',
                child: Text('Info'),
              ),
            ],
            onSelected: (String value) {
              if (value == 'option1') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SettingsPage()),
                );
              } else if (value == 'option2') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => InfoPage()),
                );
              }
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                border: Border.all(),
              ),
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Search',
                  prefixIcon: Icon(Icons.search),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
                ),
              ),
            ),
          ),
          SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HomeScreen()),
                  );
                },
                style: ButtonStyle(backgroundColor: MaterialStateProperty.all(Colors.grey)),
                child: Text('ALL', style: TextStyle(color: Colors.white)),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Albumpage()),
                  );
                },
                style: ButtonStyle(backgroundColor: MaterialStateProperty.all(Colors.grey)),
                child: Text('ALBUM', style: TextStyle(color: Colors.white)),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => PlaylistPage(folders: folders)),
                  );
                },
                style: ButtonStyle(backgroundColor: MaterialStateProperty.all(Colors.grey)),
                child: Text('PLAYLIST', style: TextStyle(color: Colors.white)),
              ),
              ElevatedButton(
                onPressed: () {
                  // Perform action for button 4
                },
                child: Text('ARTIST', style: TextStyle(color: Colors.white)),
              ),
            ],
          ),
          SizedBox(height: 10),
          Expanded(
            child: ListView.builder(
              itemCount: filteredArtists.length,
              itemBuilder: (BuildContext context, int index) {
                final artist = filteredArtists[index];
                return ListTile(
                  title: Text(artist),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ArtistDetailPage(artist: artist),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}


class ArtistDetailPage extends StatelessWidget {
  final String artist;

  ArtistDetailPage({required this.artist});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(artist),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Artist Details',
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 20),
            Text(
              'Name: $artist',
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Implement music player functionality
                // Play the artist's music
              },
              child: Text('Play Music'),


            ),
          ],
        ),
      ),
    );
  }
}





