import 'package:flutter/material.dart';
import 'package:flutter_internship/ArtistPage.dart';
import 'package:flutter_internship/InfoPage.dart';
import 'package:flutter_internship/SettingsPage.dart';
import 'package:flutter_internship/colors.dart';
import 'package:flutter_internship/PlaylistPage.dart';
import 'package:flutter_internship/homescreen.dart';
import 'package:flutter_internship/AccountPage.dart';

void main() {
  runApp(MusicPlayerApp());
}

class MusicPlayerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Music Player',
      theme: ThemeData(
        primarySwatch: mprimary, // Replace `mprimary` with a color from your `colors.dart` file or use `Colors.blue` as an example
      ),
      home: Albumpage(),
    );
  }
}

class Albumpage extends StatelessWidget {
  final List<String> albums = [
    'assets/album1.jpeg',
    'assets/album2.jpeg',
    'assets/album3.jpeg',
    'assets/album4.jpeg',
    'assets/album5.jpeg',
    'assets/album6.jpeg',
    'assets/album7.jpeg',
    'assets/album8.jpeg',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'HARMONIX',
          style: TextStyle(color: const Color(0xFFBD9458)),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.account_circle, color: const Color(0xFFBD9458)),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AccountPage()),
              );
            },
          ),
          PopupMenuButton<String>(
            icon: Icon(Icons.more_vert, color: const Color(0xFFBD9458)),
            itemBuilder: (BuildContext context) => [
              PopupMenuItem<String>(
                value: 'option1',
                child: Text('Settings'),
              ),
              PopupMenuItem<String>(
                value: 'option2',
                child: Text('Info'),
              ),
            ],
            onSelected: (String value) {
              // Handle menu option selection logic
              if (value == 'option1') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SettingsPage()),
                );
                // Handle option 1 logic
              } else if (value == 'option2') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => InfoPage()),
                );
                // Handle option 2 logic
              }
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(16.0),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                border: Border.all(),
              ),
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Search',
                  prefixIcon: Icon(Icons.search),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
                ),
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => HomeScreen()),
                  );
                  // Button 1 onPressed logic
                },
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all(Colors.grey),
                ),
                child: Text('ALL', style: TextStyle(color: Colors.white)),
              ),
              ElevatedButton(
                onPressed: () {
                  // Button 2 onPressed logic
                },
                child: Text('ALBUM', style: TextStyle(color: Colors.white)),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PlaylistPage(folders: folders),
                    ),
                  );
                  // Button 3 onPressed logic
                },
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all(Colors.grey),
                ),
                child: Text('PLAYLIST', style: TextStyle(color: Colors.white)),
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ArtistPage()),
                  );
                  // Button 4 onPressed logic
                },
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all(Colors.grey),
                ),
                child: Text('ARTIST', style: TextStyle(color: Colors.white)),
              ),
            ],
          ),
          Expanded(
            child: GridView.count(
              padding: EdgeInsets.all(16.0),
              crossAxisCount: 2,
              crossAxisSpacing: 16.0,
              mainAxisSpacing: 16.0,
              childAspectRatio: 0.6,
              children: List.generate(albums.length, (index) {
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AlbumDetailsScreen(album: albums[index]),
                      ),
                    );
                  },
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10.0),
                    child: Image.asset(
                      albums[index],
                      fit: BoxFit.cover,
                    ),
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}


class AlbumDetailsScreen extends StatelessWidget {
  final String album;

  AlbumDetailsScreen({required this.album});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Album Details'),
      ),
      body: Center(
        child: Text(
          'Album: $album',
          style: TextStyle(fontSize: 24.0),
        ),
      ),
    );
  }
}
